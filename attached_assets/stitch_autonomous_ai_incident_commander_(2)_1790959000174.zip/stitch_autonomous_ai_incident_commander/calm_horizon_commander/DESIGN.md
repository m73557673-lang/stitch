---
name: Calm Horizon Commander
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is engineered for high-pressure incident mitigation, built specifically to demystify complex distributed systems architecture for both seasoned engineers and non-technical stakeholders (such as product managers, customer support leads, and executives). 

The emotional tone balances absolute calm, reassuring transparency, and proactive intelligence. Rather than feeling like an intimidating, alarmist operations dashboard, the visual language resembles a trusted, poised colleague who distills chaos into structured, plain-language triage.

The aesthetic fuses **Corporate Modern** with **Soft Tactile Functionalism**:
- Pure, clean whites and layered slate surfaces eliminate cognitive fatigue.
- Generous internal padding and soft radii remove visual tension.
- High-contrast typography paired with soft-tinted status pills ensures critical system states can be parsed in split-second glances without inducing panic.
- AI actions are distinguished with an intelligent, gentle purple and vibrant soft blue accent language, framing machine intelligence as an orderly, reliable collaborator rather than an opaque black box.

## Colors

The color palette is built on strict hierarchy to facilitate incident management without alarming users.

### Surface & Neutral Architecture
- **Base Canvas (`#FFFFFF`)**: Pure white base providing clear contrast and crispness.
- **Surface Level 1 (`#F8FAFC`)**: Soft slate used for sidebars, global navigation rails, and card groupings.
- **Surface Level 2 (`#F1F5F9`)**: Elevated neutral used for input field backgrounds, code blocks, and inactive tab containers.
- **Border Default (`#E2E8F0`)**: Low-contrast boundary separating interactive surfaces without visual noise.
- **Text Primary (`#0F172A`)**: Slate 900 for high-contrast, effortless legibility across all ambient lighting conditions.
- **Text Secondary (`#475569`)**: Slate 600 for supportive explanations and metadata.
- **Text Muted (`#94A3B8`)**: Slate 400 for placeholders and inactive icons.

### Brand & Intelligence Accents
- **Primary Blue (`#2563EB` / Active: `#1D4ED8`)**: Primary actions, critical navigational focus, and system-wide action buttons.
- **AI Working Blue (`#3B82F6`)**: Dedicated pulse indicator and dynamic telemetry representing ongoing autonomous AI diagnosis.
- **AI Purple (`#7C3AED` / Soft: `#8B5CF6` / Tint: `#F5F3FF`)**: Applied exclusively to generative remediation suggestions, automated rollback actions, and synthesized incident debriefs.

### Semantic Triage Accents
- **Healthy / Resolved (`#10B981`, Tint: `#ECFDF5`)**: All systems operational, test suites passing, resolution confirmed.
- **Warning / Degraded (`#F59E0B`, Tint: `#FFFBEB`)**: Latency spikes, elevated memory thresholds, non-blocking errors.
- **Critical / Outage (`#EF4444`, Tint: `#FEF2F2`)**: Active downtime, customer-impacting outages, failed health checks.

## Typography

Typography pairs **Plus Jakarta Sans** for structural headers with **Inter** for data density and continuous reading. 

- **Headlines (Plus Jakarta Sans)**: The rounded terminal curves make high-stress incident titles approachable and friendly, softening the psychological impact of critical alerts.
- **Body & Labels (Inter)**: Provides neutral, clinical legibility for root-cause analyses, event timelines, and system logs. The tall x-height retains extreme readability even in compact cards or mobile viewports.
- **Code & Diagnostics**: For stack traces, shell commands, or commit hashes, pair standard system monospace typography with `fontSize: 13px` and `lineHeight: 20px`, enclosed inside `#F8FAFC` slate pill blocks.

## Layout & Spacing

The layout is built upon an 8pt base grid within a fluid-responsive structure.

### Grid & Breakpoints
- **Desktop (>= 1280px)**: 12-column layout. 3-column triage pane (real-time telemetry and service graph) paired with an 9-column incident workspace (plain-English timeline, AI analysis chat, and remediation triggers). Gutter: `1.5rem`, Margin: `2rem`.
- **Tablet (768px - 1279px)**: 8-column layout. Navigation folds to an expandable sheet; the service topology docks above the remediation timeline. Gutter: `1.25rem`, Margin: `1.5rem`.
- **Mobile (< 768px)**: 4-column layout. Single-column feed prioritizing incident severity cards, conversational action prompts, and sticky bottom resolution triggers. Gutter: `1rem`, Margin: `1rem`.

### Spacing Principles
- Never pack data tightly; give diagnostic statements breathing room using `space-lg` and `space-xl` for outer component margins to lower anxiety.
- Micro-grouping of metadata (such as timestamps, node names, and runbook tags) relies on `space-xs` and `space-sm` gap tokens to retain clear visual cohesion.

## Elevation & Depth

Visual hierarchy uses **tonal layer nesting** combined with **ambient, diffused shadow envelopes**. Deep, stark dropshadows are explicitly avoided to keep the interface light and friendly.

- **Level 0 (Base Canvas)**: `#FFFFFF`. Ground surface for the whole application.
- **Level 1 (Subtle Recessed/Docked)**: `#F8FAFC` flat surface with a hairline `#E2E8F0` border. Used for side rails, filter bars, and inactive panels.
- **Level 2 (Standard Elevated Cards)**: `#FFFFFF` surface accompanied by `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)` and a `1px solid #E2E8F0` border.
- **Level 3 (AI Action & Diagnostic Focus)**: `#FFFFFF` surface with an expanded ambient drop shadow: `0 10px 25px -5px rgba(37, 99, 235, 0.06), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` and a subtle `1px solid #DBEAFE` border.
- **Level 4 (Modals, Overlays & Emergency Drawers)**: High-altitude diffused shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 10px 10px -5px rgba(15, 23, 42, 0.03)` with a `1px solid #E2E8F0` stroke over a `rgba(15, 23, 42, 0.3)` frosted backdrop blur.

## Shapes

The design system employs a soft, highly rounded geometry (`roundedness: 2`) to ensure software incident management feels accessible, approachable, and non-punitive.

- **Micro Shapes (Badges, Status Pills, Counter Badges)**: Fully rounded (`9999px`) pill structures to accentuate immediate state recognition.
- **Inputs & Interactive Controls**: `0.75rem` (`12px`) soft corners for input fields, toggle buttons, and dropdown triggers.
- **Cards, Timeline Panels & Diagnostic Modals**: `1rem` (`16px` / `rounded-lg`) up to `1.5rem` (`24px` / `rounded-xl`) outer container boundaries, creating an inviting visual framing for incident metrics and playbooks.

## Components

### Buttons
- **Primary Incident Action**: Solid `#2563EB` background, `#FFFFFF` text, `0.75rem` radius, 12px 20px padding. Hover: `#1D4ED8`. Active: scale transform `98%`.
- **AI Autonomous Execution Button**: Subtle gradient from `#7C3AED` to `#6D28D9`, `#FFFFFF` text, paired with a leading spark/AI icon. Includes a resting glow: `0 0 12px rgba(124, 58, 237, 0.25)`.
- **Secondary / Ghost**: White background, `1px solid #E2E8F0`, `#0F172A` text. Hover: `#F8FAFC` with `#CBD5E1` border.
- **Destructive / Rollback**: `#FEF2F2` background, `1px solid #FCA5A5`, `#DC2626` text. Hover: `#FEE2E2`.

### Status Indicators & Beginner Badges
- **Status Pills**: Fully rounded (`9999px`), `4px 10px` padding. Always pair a 6px solid circular status dot with plain-language text:
  - *Healthy*: Dot `#10B981`, Background `#ECFDF5`, Text `#047857`. Label: "Healthy".
  - *Warning*: Dot `#F59E0B`, Background `#FFFBEB`, Text `#B45309`. Label: "Degraded".
  - *Critical*: Dot `#EF4444`, Background `#FEF2F2`, Text `#B91C1C`. Label: "Action Required".
  - *AI Working*: Dot `#3B82F6` (with CSS pulse animation), Background `#EFF6FF`, Text `#1D4ED8`. Label: "Investigating Root Cause...".
- **Plain-English Explainer Chips**: Light slate chips (`#F1F5F9`) with `#475569` text providing layman explanations for technical terms on hover or click (e.g., `"OOMKilled" -> "Out of Memory"`).

### Cards & Incident Panels
- Background `#FFFFFF`, border `1px solid #E2E8F0`, radius `1rem`, internal padding `space-lg`.
- Header area separates incident severity, active duration timer, and human-readable incident headline.
- Integrated AI Insight Box: Recessed box within the card with `#F5F3FF` tint, `1px solid #DDD6FE` border, and `rounded-lg` containing the recommended fix and plain-English context.

### Form Inputs & Search Filters
- Background `#F8FAFC`, border `1px solid #E2E8F0`, radius `0.75rem`, padding `10px 14px`.
- Focus state: Surface turns pure `#FFFFFF`, border shifts to `#3B82F6` with `0 0 0 3px rgba(59, 130, 246, 0.15)` ring.
- Placeholder text in `#94A3B8`.

### Checkboxes & Approval Toggles
- Sized at `20px x 20px` with `6px` corner radius.
- Unchecked: `#FFFFFF` with `#CBD5E1` border.
- Checked: `#2563EB` fill with white checkmark.
- AI Confirmation Step-lists: Checkboxes for approving sequential AI remediation steps (e.g., `[✓] Restart pod -> [✓] Flush Redis cache -> [ ] Increase replica count`).