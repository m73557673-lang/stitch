---
name: Vitality Active Insurance
colors:
  surface: '#fff8f8'
  surface-dim: '#e1d8da'
  surface-bright: '#fff8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf1f3'
  surface-container: '#f5ebed'
  surface-container-high: '#efe6e8'
  surface-container-highest: '#eae0e2'
  on-surface: '#1f1a1c'
  on-surface-variant: '#5d3f42'
  inverse-surface: '#342f31'
  inverse-on-surface: '#f8eef0'
  outline: '#916e71'
  outline-variant: '#e6bcc0'
  surface-tint: '#bd0043'
  primary: '#b90041'
  on-primary: '#ffffff'
  primary-container: '#e70054'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2ba'
  secondary: '#635d5f'
  on-secondary: '#ffffff'
  secondary-container: '#e9e0e3'
  on-secondary-container: '#696365'
  tertiary: '#006a42'
  on-tertiary: '#ffffff'
  tertiary-container: '#008654'
  on-tertiary-container: '#f6fff5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dc'
  primary-fixed-dim: '#ffb2ba'
  on-primary-fixed: '#400011'
  on-primary-fixed-variant: '#910031'
  secondary-fixed: '#e9e0e3'
  secondary-fixed-dim: '#cdc4c7'
  on-secondary-fixed: '#1f1a1c'
  on-secondary-fixed-variant: '#4b4548'
  tertiary-fixed: '#78fbb6'
  tertiary-fixed-dim: '#59de9b'
  on-tertiary-fixed: '#002111'
  on-tertiary-fixed-variant: '#005232'
  background: '#fff8f8'
  on-background: '#1f1a1c'
  surface-variant: '#eae0e2'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-energy, health-forward digital identity that breaks free from conventional, passive insurance aesthetics. It is built for proactive wellness seekers, active families, and individuals looking for insurance that actively partners in their daily health and longevity.

The design movement is **High-Contrast Modernism with Energetic Warmth**:
- **Dynamic Energy:** Anchored by punchy magenta, hot pink, and crisp white surfaces, evoking movement, vitality, and optimism.
- **Human & Approachable:** Departing from cold financial blues in favor of warm rose-tinted neutral environments, friendly rounded geometry, and accessible visual hierarchy.
- **Clarity & Confidence:** Ultra-readable modern grotesque typography paired with bold dark charcoal text creates an authoritative yet distinctly motivating tone.

## Colors

The color palette centers on high-impact vitality pink counterbalanced with deep charcoal typography and luminous rose-tinted surfaces.

- **Primary (`#ED0056` / `#E6004C`):** The signature vitality punch. Used for primary CTAs, key brand banners, milestone celebrations, active indicators, and hero highlights.
- **Secondary (`#1A1618`):** Deep volcanic charcoal. Replaces default blacks for body copy and dense headers, providing soft yet crisp contrast without starkness.
- **Tertiary (`#00A86B`):** Vitality active emerald. Reserved strictly for health progression, active streak counters, positive metrics, and verified benefit badges.
- **Neutral Canvas (`#FFF5F7`):** A subtle warm rose-white tint applied to body backgrounds and section dividers, making pure `#FFFFFF` cards pop with clarity and warmth.
- **Text & Borders:** High-contrast dark charcoal (`#1A1618`) for headline hierarchies, `#575153` for supporting metadata, and `#FCE4EC` / `#F8CCD7` for hairline borders and inactive containers.

## Typography

The design system exclusively adopts **Plus Jakarta Sans** across all roles to ensure geometric purity, contemporary clarity, and a welcoming feel.

- **Display & Headlines:** Set in extra-bold weights (`700` and `800`) with tighter letter spacing (`-0.02em`) to command attention, convey vitality, and anchor conversational claims like "Live longer with Vitality."
- **Body:** Set with generous line heights (`1.5` to `1.6`) to maintain readability across complex policy details, reward program schedules, and clinical guidance.
- **Labels & Badges:** Use bold tracking (`+0.01em` to `+0.02em`) for CTA buttons, interactive tabs, metric milestones, and status chips.

## Layout & Spacing

A balanced 12-column fluid grid system governs screen layouts, prioritizing breathable content sections and structured modular card grids.

- **Desktop (1024px+):** 12 columns with `1.5rem` gutters and `3rem` exterior margin. Maximum content boundary capped at `1280px` centered canvas.
- **Tablet (768px - 1023px):** 8 columns with `1.25rem` gutters and `2rem` margins. Multicolumn forms step down to 2 columns.
- **Mobile (<768px):** 4 columns with `1rem` gutters and `1.25rem` margins. Card lists and comparison metrics collapse into single-column vertical stacks or horizontal carousels with peek overflow.
- **Rhythm:** Spacing follows strict increments of 8px (0.5rem) and 4px (0.25rem), ensuring optical harmony between active metrics, badge chips, and form groups.

## Elevation & Depth

Visual hierarchy uses a refined combination of **tonal layers** and **subtle warm-tinted ambient shadows**:

- **Ground Level:** `#FFF5F7` provides the default background canvas, softening the interface compared to sterile pure white.
- **Card Surface (Level 1):** `#FFFFFF` surfaces with a delicate border (`1px solid #FBE8EE`) and an ultra-diffused, pink-tinted shadow (`box-shadow: 0 4px 20px -2px rgba(237, 0, 86, 0.06), 0 2px 6px -1px rgba(26, 22, 24, 0.04)`).
- **Floating & Interactive (Level 2):** Hover states, bottom navigation sheets, and active quote widgets utilize elevated lift (`box-shadow: 0 12px 32px -4px rgba(237, 0, 86, 0.12), 0 4px 12px -2px rgba(26, 22, 24, 0.06)`).
- **Brand Surfaces (Inverted):** Full-bleed hero modules and promo ribbons take `#ED0056` with white foreground text and no elevation shadows, relying strictly on saturated planar contrast.

## Shapes

The design system incorporates **Level 2 Roundedness** to project a friendly, accessible, and athletic posture:

- **Buttons & Chips:** `rounded-lg` (1rem / 16px) up to full pill shapes (`rounded-full`) for tag items, activity trackers, and primary trigger buttons.
- **Cards & Hero Panels:** `rounded-lg` (1rem / 16px) or `rounded-xl` (1.5rem / 24px) on standalone feature banners.
- **Inputs & Form Controls:** `rounded-md` (0.5rem / 8px) with inset padding, balancing functional structure with soft visual corners.

## Components

### Buttons
- **Primary:** Solid `#ED0056` fill, `#FFFFFF` bold label text, `0.75rem 1.75rem` padding, rounded pill radius. Subtle lift on hover with background shifting to `#D9004E`.
- **Secondary (Outline):** Pure white background or transparent, `2px solid #ED0056`, label text `#ED0056`. Hover fills with `#FFF0F4`.
- **Inverted (Hero Surface):** Pure `#FFFFFF` card button on pink heroes with text in `#ED0056` and subtle shadow lift.

### Cards
- **Product & Tier Cards:** Solid `#FFFFFF` background, `1px solid #FCE4EC`, `1.5rem` internal padding, `rounded-xl` shape. Top badges float inside the card with pill styling.
- **Interactive Metric Cards:** Feature a left-hand accent border (`4px solid #ED0056` or `#00A86B` for rewards).

### Chips & Badges
- **Status & Reward Badges:** Compact pill chips (`0.25rem 0.75rem`) set in `#FFF0F4` with `#ED0056` text for perks, and `#E8F8F2` with `#00A86B` text for verified healthy achievements.

### Input Fields & Selects
- Crisp `#FFFFFF` surface with `1.5px solid #E2D9DC` border. Focused state transitions smoothly to `2px solid #ED0056` accompanied by a soft pink glow (`box-shadow: 0 0 0 3px rgba(237, 0, 86, 0.15)`).

### Checkboxes & Radios
- Rounded `0.375rem` boxes for checkboxes, circular for radios. Selected states fill with `#ED0056` and display crisp white checkmarks or inner dots.

### Health & Activity Trackers
- Circular and linear progress bars built with a dual-color track: `#FBE8EE` inactive track overlaid with `#ED0056` or `#00A86B` animated fills, paired with bold numeric counters.